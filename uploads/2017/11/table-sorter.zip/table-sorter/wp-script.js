jQuery(document).ready(function($) {
	$('.tablesorter .sortless').addClass('{sorter: false}');
	$('.tablesorter').tablesorter();
});